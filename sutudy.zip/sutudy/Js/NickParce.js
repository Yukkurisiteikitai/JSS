let y = 12**2
document.write('半径12cmの円の面積は、');
document.write(y);
document.write('cm<sup>2</sup>です');