a = '{0'
b = 0

for i in range(9):
    a += ',0'
    b +=1
a += '},'
print(a)

for n in range(9):
    print(a)

print(b)