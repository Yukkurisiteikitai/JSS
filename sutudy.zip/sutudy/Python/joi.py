out = ''


while True:
    code = input('goTO:')
    out += '"' +code+ '",'
    print(out)