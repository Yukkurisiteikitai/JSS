for(var i=0;i <= 100;i++){

    if(i % 3 === 0){
        document.write(i + "Quiet");

    }else{
    document.write(i + " ");

    }
}