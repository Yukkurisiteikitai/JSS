let age = 16;
let isMember = true;
let value = 0;

if(age <= 15){
    value = 800;
}else if(age >= 16&&isMember){
    value = 1000;
}else{
    value = 1800;
}
document.write(value + "円");