let code = document.getElementById('code');

let degree = 0;
//code.style.color = "black";

function rotateHeading(){
    degree += 6;
    degree %= 360;
    
    if(90<=degree && degree < 270){
        code.setAttribute('class','back');
    }else{
        code.setAttribute('class','face');
    }
    
    code.style.transform = 'rotateX(' + degree + 'deg)';
    code.style.transform = 'rotateX(' + degree + 'deg)';
}
setInterval(rotateHeading,20);