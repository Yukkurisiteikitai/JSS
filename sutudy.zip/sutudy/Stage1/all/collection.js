let game={
    startTime:null,
    stopTIme:null,
    seconds:null,
    displayArea:document.getElementById('display-area'),
    start:function(){
        game.displayArea.innerHTML='計測中';
        game.startTime = Date.now();

    },
    stop:function(){
        game.stopTIme=Date.now();
        game.seconds=(game.stopTIme-game.startTime)/1000;
        if(game.seconds>=9.5&&game.seconds>10.5){
            game.displayArea.innerHTML=game.seconds+'秒でした。すご!'
        }else{
            game.displayArea.innerHTML=game.seconds+'秒でした。なんで'

        }
    }

    
}
console.dir('joker');

if(confirm('You count 10.You feel count 10 when click anykey.')){
game.start();
}
document.body.addEventListener('keydown',game.stop);

