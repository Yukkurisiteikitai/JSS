let Isay = ["なぜこのようなことをしなければならなかったのか","Why do you do","意味"];

/*
let heading = document.getElementById('face');
heading.style.transform = 'rotateX(60deg)';
heading.style.color = "red";

let degree = 0;
function rottateHeading(){
    degree = degree + 60;
    heading.style.transform = 'rotateX(' + degree + 'deg)';
}
setInterval(rottateHeading,20);*/